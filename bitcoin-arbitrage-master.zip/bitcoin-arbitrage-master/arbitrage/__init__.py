from arbitrage import arbitrage

arbitrage.main()
